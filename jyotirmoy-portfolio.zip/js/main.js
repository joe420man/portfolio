/* ============================================================
   JYOTIRMOY NAG — cinematic scroll engine
   Lenis smooth scroll + GSAP ScrollTrigger + canvas frame scrub
   ============================================================ */

gsap.registerPlugin(ScrollTrigger);

const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];

/* ------------------------------------------------------------
   Lenis smooth scroll, driven by GSAP's ticker
------------------------------------------------------------ */
const lenis = new Lenis({
  duration: 1.15,
  easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
  smoothWheel: true,
});
lenis.on('scroll', ScrollTrigger.update);
gsap.ticker.add((time) => lenis.raf(time * 1000));
gsap.ticker.lagSmoothing(0);

// anchor links through Lenis
$$('a[href^="#"]').forEach((a) => {
  a.addEventListener('click', (e) => {
    const target = $(a.getAttribute('href'));
    if (!target) return;
    e.preventDefault();
    lenis.scrollTo(target, { offset: 0, duration: 1.6 });
  });
});

/* ------------------------------------------------------------
   Hero frame sequence — loaded from manifest.json
------------------------------------------------------------ */
const canvas = $('#heroCanvas');
const ctx = canvas.getContext('2d');
const heroState = { frame: 0, frames: [], count: 0, ready: false };

function sizeCanvas() {
  const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
  canvas.width = Math.round(canvas.clientWidth * dpr);
  canvas.height = Math.round(canvas.clientHeight * dpr);
  drawFrame(heroState.frame);
}

function drawFrame(i) {
  const img = heroState.frames[Math.max(0, Math.min(i, heroState.count - 1))];
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  if (!img) { drawFallback(); return; }
  // cover-fit
  const cw = canvas.width, ch = canvas.height;
  const iw = img.width, ih = img.height;
  const scale = Math.max(cw / iw, ch / ih);
  const w = iw * scale, h = ih * scale;
  ctx.drawImage(img, (cw - w) / 2, (ch - h) / 2, w, h);
}

function drawFallback() {
  const g = ctx.createRadialGradient(
    canvas.width / 2, canvas.height * 0.42, 0,
    canvas.width / 2, canvas.height * 0.42, canvas.width * 0.6
  );
  g.addColorStop(0, '#0e2018');
  g.addColorStop(0.55, '#0a120d');
  g.addColorStop(1, '#070807');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
}

const preloaderCount = $('#preloaderCount');
const preloaderBar = $('#preloaderBar');

function setProgress(p) {
  const pct = Math.round(p * 100);
  preloaderCount.textContent = pct + '%';
  preloaderBar.style.width = pct + '%';
}

async function loadFrames() {
  let manifest = null;
  try {
    const res = await fetch('assets/frames/hero/manifest.json', { cache: 'no-store' });
    if (res.ok) manifest = await res.json();
  } catch (e) { /* no frames yet — fallback mode */ }

  if (!manifest || !manifest.count) {
    // graceful fallback: fake a short load, keep gradient backdrop
    for (let i = 0; i <= 20; i++) {
      setProgress(i / 20);
      await new Promise((r) => setTimeout(r, 22));
    }
    return;
  }

  heroState.count = manifest.count;
  const pad = manifest.pad || 4;
  const ext = manifest.ext || 'jpg';
  let loaded = 0;

  const jobs = [];
  for (let i = 0; i < manifest.count; i++) {
    const src = `assets/frames/hero/frame_${String(i + 1).padStart(pad, '0')}.${ext}`;
    jobs.push(new Promise((resolve) => {
      const img = new Image();
      img.onload = async () => {
        try {
          heroState.frames[i] = await createImageBitmap(img);
        } catch (e) {
          heroState.frames[i] = img;
        }
        loaded++;
        setProgress(loaded / manifest.count);
        resolve();
      };
      img.onerror = () => { loaded++; setProgress(loaded / manifest.count); resolve(); };
      img.src = src;
    }));
  }
  await Promise.all(jobs);
  heroState.ready = true;
}

/* ------------------------------------------------------------
   Intro — preloader out, title tracks in letter by letter
------------------------------------------------------------ */
function splitChars(el) {
  const text = el.textContent;
  el.textContent = '';
  const frag = document.createDocumentFragment();
  for (const ch of text) {
    const span = document.createElement('span');
    span.className = 'char';
    span.innerHTML = ch === ' ' ? '&nbsp;' : ch;
    frag.appendChild(span);
  }
  el.appendChild(frag);
}

function intro() {
  $$('.hero__line').forEach(splitChars);

  const tl = gsap.timeline();
  tl.to('#preloader', {
    autoAlpha: 0, duration: 0.7, ease: 'power2.inOut',
    onComplete: () => { const p = $('#preloader'); if (p) p.remove(); },
  })
    .from('.hero__line .char', {
      yPercent: 118,
      rotate: 6,
      opacity: 0,
      duration: 1.15,
      stagger: 0.045,
      ease: 'power4.out',
    }, '-=0.15')
    .from('#heroEyebrow', { y: 24, opacity: 0, duration: 0.8, ease: 'power3.out' }, '-=0.8')
    .from('#heroSubtitle', { y: 24, opacity: 0, duration: 0.8, ease: 'power3.out' }, '-=0.6')
    .from('#scrollCue', { opacity: 0, duration: 0.8 }, '-=0.4')
    .to('#nav', { opacity: 1, duration: 0.8 }, '-=0.6');
}

/* ------------------------------------------------------------
   Hero scrub — orbit frames + content drift
------------------------------------------------------------ */
function heroScrub() {
  const proxy = { frame: 0 };
  gsap.to(proxy, {
    frame: () => Math.max(heroState.count - 1, 0),
    ease: 'none',
    scrollTrigger: {
      trigger: '#hero',
      start: 'top top',
      end: 'bottom bottom',
      scrub: 0.6,
    },
    onUpdate: () => {
      const f = Math.round(proxy.frame);
      if (f !== heroState.frame) {
        heroState.frame = f;
        drawFrame(f);
      }
    },
  });

  // content drifts out as the orbit progresses
  gsap.to('.hero__content', {
    yPercent: -18,
    autoAlpha: 0,
    ease: 'none',
    scrollTrigger: {
      trigger: '#hero',
      start: '55% bottom',
      end: 'bottom bottom',
      scrub: true,
    },
  });
  gsap.to('#scrollCue', {
    autoAlpha: 0,
    ease: 'none',
    scrollTrigger: {
      trigger: '#hero',
      start: 'top top',
      end: '12% bottom',
      scrub: true,
    },
  });
}

/* ------------------------------------------------------------
   Marquee — scroll-linked kinetic type
------------------------------------------------------------ */
function marquee() {
  const track = $('[data-marquee]');
  if (!track) return;
  gsap.to(track, {
    xPercent: -33.333,
    ease: 'none',
    scrollTrigger: {
      trigger: '.marquee',
      start: 'top bottom',
      end: 'bottom top',
      scrub: 0.8,
    },
  });
}

/* ------------------------------------------------------------
   Stats — count up on entry
------------------------------------------------------------ */
function stats() {
  $$('[data-stat]').forEach((el, i) => {
    gsap.from(el, {
      y: 46,
      opacity: 0,
      duration: 0.9,
      delay: i * 0.08,
      ease: 'power3.out',
      scrollTrigger: { trigger: '#stats', start: 'top 78%' },
    });
  });
  $$('.stat__num').forEach((el) => {
    const target = +el.dataset.count;
    const proxy = { v: 0 };
    gsap.to(proxy, {
      v: target,
      duration: 1.8,
      ease: 'power2.out',
      scrollTrigger: { trigger: el, start: 'top 82%' },
      onUpdate: () => { el.textContent = Math.round(proxy.v); },
    });
  });
}

/* ------------------------------------------------------------
   Pillars — pinned sequence over THE BUILDER clip
------------------------------------------------------------ */
function pillars() {
  const items = $$('[data-pillar]');
  const fill = $('#pillarsProgress');

  const tl = gsap.timeline({
    scrollTrigger: {
      trigger: '#pillars',
      start: 'top top',
      end: 'bottom bottom',
      scrub: 0.5,
      onUpdate: (self) => { fill.style.height = (self.progress * 100) + '%'; },
    },
  });

  items.forEach((item, i) => {
    tl.fromTo(item,
      { autoAlpha: 0, y: 90 },
      { autoAlpha: 1, y: 0, duration: 1, ease: 'power3.out' }
    );
    tl.to(item, { duration: 1.4 }); // hold
    if (i < items.length - 1) {
      tl.to(item, { autoAlpha: 0, y: -70, duration: 1, ease: 'power3.in' });
    }
  });

  // header entrance
  gsap.from('.pillars__header', {
    y: 60, opacity: 0, duration: 1, ease: 'power3.out',
    scrollTrigger: { trigger: '#pillars', start: 'top 60%' },
  });
}

/* ------------------------------------------------------------
   Work — cards entrance + magnetic hover glow
------------------------------------------------------------ */
function work() {
  gsap.from('.work__header', {
    y: 60, opacity: 0, duration: 1, ease: 'power3.out',
    scrollTrigger: { trigger: '#work', start: 'top 70%' },
  });
  $$('[data-card]').forEach((card, i) => {
    gsap.from(card, {
      y: 90, opacity: 0, duration: 1, delay: i * 0.12, ease: 'power3.out',
      scrollTrigger: { trigger: '.work__cards', start: 'top 82%' },
    });
    card.addEventListener('mousemove', (e) => {
      const r = card.getBoundingClientRect();
      card.style.setProperty('--mx', ((e.clientX - r.left) / r.width) * 100 + '%');
      card.style.setProperty('--my', ((e.clientY - r.top) / r.height) * 100 + '%');
      const rx = ((e.clientY - r.top) / r.height - 0.5) * -5;
      const ry = ((e.clientX - r.left) / r.width - 0.5) * 5;
      card.style.transform = `perspective(900px) rotateX(${rx}deg) rotateY(${ry}deg) translateY(-10px)`;
    });
    card.addEventListener('mouseleave', () => { card.style.transform = ''; });
  });
}

/* ------------------------------------------------------------
   Finale — big type reveal
------------------------------------------------------------ */
function finale() {
  $$('[data-finale-line]').forEach((line) => {
    const inner = document.createElement('span');
    inner.className = 'word';
    inner.textContent = line.textContent;
    line.textContent = '';
    line.appendChild(inner);
  });
  gsap.from('.finale__line .word', {
    yPercent: 112,
    duration: 1.1,
    stagger: 0.09,
    ease: 'power4.out',
    scrollTrigger: { trigger: '#contact', start: 'top 62%' },
  });
  gsap.from('[data-finale-actions]', {
    y: 40, opacity: 0, duration: 0.9, ease: 'power3.out',
    scrollTrigger: { trigger: '#contact', start: 'top 45%' },
  });
  gsap.from('.footer', {
    opacity: 0, duration: 1,
    scrollTrigger: { trigger: '.footer', start: 'top 96%' },
  });
}

/* ------------------------------------------------------------
   Background videos — play only while visible
------------------------------------------------------------ */
function videoGating() {
  [['#pillarsVideo', '#pillars'], ['#workVideo', '#work']].forEach(([vSel, tSel]) => {
    const video = $(vSel);
    if (!video) return;
    video.addEventListener('error', () => { video.style.display = 'none'; }, true);
    ScrollTrigger.create({
      trigger: tSel,
      start: 'top bottom',
      end: 'bottom top',
      onEnter: () => video.play().catch(() => {}),
      onEnterBack: () => video.play().catch(() => {}),
      onLeave: () => video.pause(),
      onLeaveBack: () => video.pause(),
    });
  });
}

/* ------------------------------------------------------------
   Boot
------------------------------------------------------------ */
(async function boot() {
  sizeCanvas();
  drawFallback();
  window.addEventListener('resize', () => { sizeCanvas(); ScrollTrigger.refresh(); });

  await document.fonts.ready;
  await loadFrames();
  drawFrame(0);

  intro();
  heroScrub();
  marquee();
  stats();
  pillars();
  work();
  finale();
  videoGating();
  ScrollTrigger.refresh();
})();
