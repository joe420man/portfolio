# Downloads the three Seedance clips and slices the hero orbit into scrub frames.
# Usage: powershell -File process_clips.ps1 -HeroUrl <url> -BuilderUrl <url> -CloserUrl <url>
param(
  [Parameter(Mandatory=$true)][string]$HeroUrl,
  [Parameter(Mandatory=$true)][string]$BuilderUrl,
  [Parameter(Mandatory=$true)][string]$CloserUrl
)

$root = "C:\Users\HP\jyotirmoy-portfolio"
$ffmpeg = python -c "import imageio_ffmpeg; print(imageio_ffmpeg.get_ffmpeg_exe())"

Write-Output "Downloading clips..."
curl.exe -sL $HeroUrl -o "$root\assets\video\hero.mp4"
curl.exe -sL $BuilderUrl -o "$root\assets\video\builder.mp4"
curl.exe -sL $CloserUrl -o "$root\assets\video\closer.mp4"
Get-ChildItem "$root\assets\video" | Select-Object Name, Length | Out-String | Write-Output

Write-Output "Extracting hero frames (20fps, 1600px wide, q3 JPEG)..."
Remove-Item "$root\assets\frames\hero\*.jpg" -ErrorAction SilentlyContinue
& $ffmpeg -y -i "$root\assets\video\hero.mp4" -vf "fps=20,scale=1600:-2" -q:v 3 "$root\assets\frames\hero\frame_%04d.jpg" -loglevel error

$frames = @(Get-ChildItem "$root\assets\frames\hero\frame_*.jpg")
$count = $frames.Count
$totalMB = [math]::Round(($frames | Measure-Object Length -Sum).Sum / 1MB, 1)
Set-Content -Path "$root\assets\frames\hero\manifest.json" -Value ("{""count"": $count, ""pad"": 4, ""ext"": ""jpg""}") -Encoding utf8
Write-Output "Frames: $count | Total: $totalMB MB | manifest.json written"
